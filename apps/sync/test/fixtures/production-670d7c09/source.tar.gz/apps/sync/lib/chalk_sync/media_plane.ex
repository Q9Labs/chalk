defmodule ChalkSync.MediaPlane do
  @moduledoc """
  Provider-neutral server-control port for observed media publications.

  Granting publication changes server-side permission only. Enabling local
  capture is deliberately absent from this behavior because it remains a
  client-runtime consent action.

  Observation cursors must be monotonic for a Episode. `sequence` increases
  within one provider `incarnation`; after an observer restart, the adapter
  must use an `incarnation` greater than every incarnation it previously
  exposed. Repeated cursors must carry the same publication snapshot.
  """

  alias ChalkSync.Stateholder.EpisodeKey

  @type source :: :microphone | :camera | :screen
  @type outcome ::
          :confirmed
          | :satisfied
          | {:retryable_failure, atom()}
          | {:terminal_failure, atom()}
          | :ambiguous
  @type publication :: %{
          participant_id: String.t(),
          source: source() | :screen_audio,
          enabled: boolean(),
          publication_id: String.t() | nil
        }
  @type observation :: %{
          incarnation: non_neg_integer(),
          sequence: non_neg_integer(),
          publications: [publication()]
        }

  @callback grant_publication(
              adapter :: term(),
              operation_id :: String.t(),
              EpisodeKey.t(),
              participant_id :: String.t(),
              source()
            ) :: outcome()
  @callback revoke_publication(
              adapter :: term(),
              operation_id :: String.t(),
              EpisodeKey.t(),
              participant_id :: String.t(),
              source()
            ) :: outcome()
  @callback remove_participant(
              adapter :: term(),
              operation_id :: String.t(),
              EpisodeKey.t(),
              participant_id :: String.t()
            ) :: outcome()
  @callback end_episode(
              adapter :: term(),
              operation_id :: String.t(),
              EpisodeKey.t()
            ) :: outcome()
  @callback observe_episode_publications(adapter :: term(), EpisodeKey.t()) ::
              {:ok, observation()} | {:error, atom()}
end
