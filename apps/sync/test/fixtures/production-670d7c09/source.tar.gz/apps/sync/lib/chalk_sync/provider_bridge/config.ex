defmodule ChalkSync.ProviderBridge.Config do
  @moduledoc false

  alias ChalkSync.ProviderBridge.Client
  alias ChalkSync.ProviderBridge.MediaPlane
  alias ChalkSync.ProviderBridge.RecordingPlane

  # Disconnected provider connections can take about twenty seconds to report
  # absence. Leave overhead above the API teardown budget and below the worker.
  @request_timeout_ms 30_000
  @certificate_types [:Certificate, :TrustedCertificate]
  @private_key_types [:PrivateKeyInfo, :RSAPrivateKey, :ECPrivateKey]

  @spec media_plane!(keyword(), pos_integer()) :: {module(), MediaPlane.t()}
  def media_plane!(options, consumer_timeout_ms) do
    client = consumer_client!(options, consumer_timeout_ms)
    {MediaPlane, MediaPlane.new!(client)}
  end

  @spec recording_plane!(keyword(), pos_integer()) :: {module(), RecordingPlane.t()}
  def recording_plane!(options, consumer_timeout_ms) do
    client = consumer_client!(options, consumer_timeout_ms)
    {RecordingPlane, RecordingPlane.new!(client)}
  end

  defp consumer_client!(options, consumer_timeout_ms) do
    if @request_timeout_ms >= consumer_timeout_ms do
      raise ArgumentError,
            "provider bridge request timeout must be shorter than the external operation timeout"
    end

    client!(options)
  end

  @spec install_media_plane!(keyword(), pos_integer()) :: {module(), MediaPlane.t()}
  def install_media_plane!(options, consumer_timeout_ms) do
    media_plane = media_plane!(options, consumer_timeout_ms)
    :ok = Application.put_env(:chalk_sync, :media_plane, media_plane)
    media_plane
  end

  @spec client!(keyword(), pos_integer()) :: Client.t()
  def client!(options, request_timeout_ms \\ @request_timeout_ms)

  def client!(options, request_timeout_ms)
      when is_list(options) and is_integer(request_timeout_ms) and request_timeout_ms > 0 do
    validate_pem_file!(
      Keyword.fetch!(options, :certfile),
      @certificate_types,
      "client certificate"
    )

    validate_pem_file!(
      Keyword.fetch!(options, :keyfile),
      @private_key_types,
      "client private key"
    )

    validate_pem_file!(Keyword.fetch!(options, :cacertfile), @certificate_types, "CA certificate")

    options
    |> Keyword.put(:connect_timeout, min(request_timeout_ms, 2_000))
    |> Keyword.put(:request_timeout, request_timeout_ms)
    |> Client.new!()
  end

  def client!(_options, _request_timeout_ms),
    do: raise(ArgumentError, "provider bridge configuration is invalid")

  defp validate_pem_file!(path, accepted_types, label) do
    case File.read(path) do
      {:ok, pem} ->
        validate_pem_contents!(pem, accepted_types, label)

      {:error, reason} ->
        raise ArgumentError,
              "provider bridge #{label} is unavailable: #{:file.format_error(reason)}"
    end
  end

  defp validate_pem_contents!(pem, accepted_types, label) do
    entries = :public_key.pem_decode(pem)

    if Enum.any?(entries, &accepted_entry?(&1, accepted_types)),
      do: :ok,
      else: raise(ArgumentError, "provider bridge #{label} is not a valid PEM file")
  end

  defp accepted_entry?({type, _contents, _cipher} = entry, accepted_types),
    do: type in accepted_types and decodable_entry?(entry)

  defp decodable_entry?(entry) do
    _decoded = :public_key.pem_entry_decode(entry)
    true
  rescue
    _exception -> false
  catch
    :exit, _reason -> false
  end
end
