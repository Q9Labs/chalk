import Config

config :chalk_sync,
  database_pool_size: 8,
  enforce_production_boot_checks: false,
  external_operation_adapter_timeout_ms: 35_000,
  external_operation_poll_interval_ms: 100,
  instance_id: nil,
  listen_ip: {127, 0, 0, 1},
  max_synchronous_wal_lag_bytes: 0,
  port: 4100,
  # Sync requires the complete release migration set before it reports ready.
  minimum_compatible_sync_migration: 20_260_819_130_000,
  provider_bridge: nil,
  retention_cleanup_interval_ms: 1_000,
  require_production_auth: false,
  require_synchronous_standby: false,
  stateholder: ChalkSync.Stateholder.Memory,
  token_verifier: ChalkSync.Auth.DevTokenVerifier,
  token_audience: nil,
  token_issuer: nil,
  token_public_keys: %{},
  observability: [enabled: false, runtime_health_interval_ms: 30_000]

config :opentelemetry, traces_exporter: :none
config :opentelemetry_exporter, otlp_protocol: :http_protobuf

import_config "#{config_env()}.exs"
